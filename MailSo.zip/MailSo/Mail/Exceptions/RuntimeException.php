<?php

/* -AFTERLOGIC LICENSE HEADER- */

namespace MailSo\Mail\Exceptions;

/**
 * @category MailSo
 * @package Mail
 * @subpackage Exceptions
 */
class RuntimeException extends \MailSo\Mail\Exceptions\Exception {}
