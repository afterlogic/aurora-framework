<?php

/* -AFTERLOGIC LICENSE HEADER- */

namespace MailSo\Mail\Exceptions;

/**
 * @category MailSo
 * @package Mail
 * @subpackage Exceptions
 */
class NonEmptyFolder extends \MailSo\Mail\Exceptions\RuntimeException {}
