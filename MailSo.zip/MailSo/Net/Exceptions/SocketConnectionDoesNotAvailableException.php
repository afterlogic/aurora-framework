<?php

/* -AFTERLOGIC LICENSE HEADER- */

namespace MailSo\Net\Exceptions;

/**
 * @category MailSo
 * @package Net
 * @subpackage Exceptions
 */
class SocketConnectionDoesNotAvailableException extends \MailSo\Net\Exceptions\ConnectionException {}
