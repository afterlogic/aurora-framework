<?php

/* -AFTERLOGIC LICENSE HEADER- */

namespace MailSo\Net\Exceptions;

/**
 * @category MailSo
 * @package Net
 * @subpackage Exceptions
 */
class SocketReadTimeoutException extends \MailSo\Net\Exceptions\Exception {}
