<?php

/* -AFTERLOGIC LICENSE HEADER- */

namespace MailSo\Poppassd\Exceptions;

/**
 * @category MailSo
 * @package Poppassd
 * @subpackage Exceptions
 */
class NegativeResponseException extends \MailSo\Poppassd\Exceptions\ResponseException {}
