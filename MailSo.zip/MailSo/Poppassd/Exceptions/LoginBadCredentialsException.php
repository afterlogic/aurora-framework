<?php

/* -AFTERLOGIC LICENSE HEADER- */

namespace MailSo\Poppassd\Exceptions;

/**
 * @category MailSo
 * @package Poppassd
 * @subpackage Exceptions
 */
class LoginBadCredentialsException extends \MailSo\Poppassd\Exceptions\NegativeResponseException {}
