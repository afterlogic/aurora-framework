<?php

/* -AFTERLOGIC LICENSE HEADER- */

namespace MailSo\Imap\Exceptions;

/**
 * @category MailSo
 * @package Imap
 * @subpackage Exceptions
 */
class ResponseNotFoundException extends \MailSo\Imap\Exceptions\Exception {}
