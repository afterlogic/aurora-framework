<?php

/* -AFTERLOGIC LICENSE HEADER- */

namespace MailSo\Base\Exceptions;

/**
 * @category MailSo
 * @package Base
 * @subpackage Exceptions
 */
class InvalidArgumentException extends \MailSo\Base\Exceptions\Exception {}
