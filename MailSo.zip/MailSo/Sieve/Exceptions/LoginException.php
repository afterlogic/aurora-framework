<?php

/* -AFTERLOGIC LICENSE HEADER- */

namespace MailSo\Sieve\Exceptions;

/**
 * @category MailSo
 * @package Sieve
 * @subpackage Exceptions
 */
class LoginException extends \MailSo\Sieve\Exceptions\NegativeResponseException {}
