<?php

/* -AFTERLOGIC LICENSE HEADER- */

namespace MailSo\Smtp\Exceptions;

/**
 * @category MailSo
 * @package Smtp
 * @subpackage Exceptions
 */
class LoginBadMethodException extends \MailSo\Smtp\Exceptions\LoginException {}
