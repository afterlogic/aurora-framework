<?php

/* -AFTERLOGIC LICENSE HEADER- */

namespace MailSo\Smtp\Exceptions;

/**
 * @category MailSo
 * @package Smtp
 * @subpackage Exceptions
 */
class NegativeResponseException extends \MailSo\Smtp\Exceptions\ResponseException {}
