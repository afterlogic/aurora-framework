<?php

/* -AFTERLOGIC LICENSE HEADER- */

namespace MailSo\Pop3\Exceptions;

/**
 * @category MailSo
 * @package Pop3
 * @subpackage Exceptions
 */
class Exception extends \MailSo\Base\Exceptions\Exception {}
